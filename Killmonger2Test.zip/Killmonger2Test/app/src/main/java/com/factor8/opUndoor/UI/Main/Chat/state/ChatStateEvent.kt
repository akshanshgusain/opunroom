package com.factor8.opUndoor.UI.Main.Chat.state

sealed class ChatStateEvent {

}