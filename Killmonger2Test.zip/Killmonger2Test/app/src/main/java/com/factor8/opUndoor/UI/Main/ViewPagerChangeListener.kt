package com.factor8.opUndoor.UI.Main

interface ViewPagerChangeListener {
    fun changeViewPagerPositionTo(position: Int)
}