package com.factor8.opUndoor;

public class SingleHeadingList {
    private String heading;

    public SingleHeadingList(String heading) {
        this.heading = heading;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }
}
