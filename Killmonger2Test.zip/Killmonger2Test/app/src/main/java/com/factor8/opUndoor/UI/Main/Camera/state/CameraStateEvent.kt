package com.factor8.opUndoor.UI.Main.Camera.state

sealed class CameraStateEvent{

}