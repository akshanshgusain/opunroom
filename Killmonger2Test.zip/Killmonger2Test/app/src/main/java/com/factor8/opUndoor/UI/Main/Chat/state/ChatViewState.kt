package com.factor8.opUndoor.UI.Main.Chat.state

import com.factor8.opUndoor.Models.AuthToken

data class ChatViewState(
        var authToken: AuthToken? = null

)