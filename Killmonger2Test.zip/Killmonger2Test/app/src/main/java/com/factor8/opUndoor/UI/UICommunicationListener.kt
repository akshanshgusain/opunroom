package com.factor8.opUndoor.UI

interface UICommunicationListener {

    fun onUIMessageReceived(uiMessage: UIMessage)
}