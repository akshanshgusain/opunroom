package com.factor8.opUndoor.SwipableViews;

public interface ButtonClickListener {
    void buttonClickListener(int position);

}
