package com.factor8.opUndoor.UI.Main.Camera.state


import com.factor8.opUndoor.Models.AuthToken

data class CameraViewState(
        var authToken: AuthToken? = null

)
