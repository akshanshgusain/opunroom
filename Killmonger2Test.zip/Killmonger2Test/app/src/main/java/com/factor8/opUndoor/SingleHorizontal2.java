package com.factor8.opUndoor;

public class SingleHorizontal2 {
          private String image, title, admin ;

    public SingleHorizontal2(String image, String title, String admin) {
        this.image = image;
        this.title = title;
        this.admin = admin;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }
}
